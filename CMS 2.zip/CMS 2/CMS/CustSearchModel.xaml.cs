﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMSBAL;
using CMSEntities;
using CMSExceptions;

namespace CMS
{
    /// <summary>
    /// Interaction logic for CustSearchModel.xaml
    /// </summary>
    public partial class CustSearchModel : Window
    {
        public CustSearchModel()
        {
            InitializeComponent();
        }

        private void BtnSearchCarbymodel_Click(object sender, RoutedEventArgs e)
        {
            Searchcarbymodel();
        }

        private void Btnreturn_Click(object sender, RoutedEventArgs e)
        {
            Customer cust = new Customer();
            cust.Show();
            this.Close();
        }
        private void Searchcarbymodel()
        {
            try
            {
                string model = txtModel.Text;
                if (txtModel.Text != "")
                {
                    CarEntities objCar = CarBAL.SearchCarByModelBAL(model);
                    if (objCar != null)
                    {
                        cmbManufacturerName.Text = objCar.ManufacturerName.ToString();
                        cmbCarType.Text = objCar.Type.ToString();
                        txtEngine.Text = objCar.Engine;
                        txtBHP.Text = objCar.BHP.ToString();
                        cmbTransmissionType.Text = objCar.Transmission.ToString();
                        txtMileage.Text = objCar.Mileage.ToString();
                        txtSeats.Text = objCar.Seats.ToString();
                        txtAirbags.Text = objCar.AirBagDetails;
                        txtBootSpace.Text = objCar.BootSpace.ToString();
                        txtPrice.Text = objCar.Price.ToString();
                    }
                    else
                    {
                        MessageBox.Show("No Car records available.");
                    }
                }
                else
                    MessageBox.Show("Please Enter Model");

            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
