﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMSBAL;
using CMSEntities;
using CMSExceptions;

namespace CMS
{
    /// <summary>
    /// Interaction logic for GetCarList.xaml
    /// </summary>
    public partial class GetCarList : Window
    {
        public GetCarList()
        {
            InitializeComponent();
        }




        private void Btnreturn_Click_1(object sender, RoutedEventArgs e)
        {
            Admin adm = new Admin();
            adm.Show();
            this.Close();
        }

        private void BtnListCars_Click(object sender, RoutedEventArgs e)
        {
            

            Searchcarbyname(); 

        }



        private void BtnSearchByName_Click(object sender, RoutedEventArgs e)
        {
            Searchcarbyname();
        }
        private void Searchcarbyname()
        {
            try
            {
                string name = cmbname.Text;
                string type = cmbtype.Text;
                if (cmbname.Text != "" || cmbtype.Text != "")
                {
                    List<CarEntities> objCars = CarBAL.SearchCarByNameBAL(name, type);
                    if (objCars != null)
                    {
                        dgList.ItemsSource = objCars;
                    }
                    else
                    {
                        MessageBox.Show("No records available.");
                    }
                }
                else
                    MessageBox.Show("Please Enter type And Manufacturer");
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
        
