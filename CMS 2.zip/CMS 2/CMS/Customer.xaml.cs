﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CMS
{
    /// <summary>
    /// Interaction logic for Customer.xaml
    /// </summary>
    public partial class Customer : Window
    {
        public Customer()
        {
            InitializeComponent();
        }

       

        

        private void Return_Click(object sender, RoutedEventArgs e)
        {
            MainWindow objmain = new MainWindow();
            objmain.Show();
            this.Close();
        }

        private void BtnSearchCarByName_Click(object sender, RoutedEventArgs e)
        {
            CustSearchName carModel = new CustSearchName();
            carModel.Show();
            this.Close();

        }

        private void BtnSearchCarByModel_Click(object sender, RoutedEventArgs e)
        {
            CustSearchModel carModel = new CustSearchModel();
            carModel.Show();
            this.Close();

        }
    }
}
 