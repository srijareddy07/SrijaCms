﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMSBAL;
using CMSEntities;
using CMSExceptions;

namespace CMS
{
    /// <summary>
    /// Interaction logic for UpdateCar.xaml
    /// </summary>
    public partial class UpdateCar : Window
    {
        public UpdateCar()
        {
            InitializeComponent();
        }



        private void Updatecar_Click_1(object sender, RoutedEventArgs e)
        {
            Updatecardetails();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }
        private void Updatecardetails()
        {
            bool CarUpdated;
            try
            {

                CarEntities objcar = new CarEntities();

                objcar.ManufacturerName = cmbManufacturerName.Text;
                objcar.Model = txtModel.Text;
                objcar.Type = cmbType.Text;
                objcar.Engine = txtEngine.Text;
                objcar.BHP = Convert.ToInt32(txtBHP.Text);
                objcar.Transmission = cmbTransmissionId.Text;
                objcar.Mileage = Convert.ToInt32(txtMileage.Text);
                objcar.Seats = Convert.ToInt32(txtSeats.Text);
                objcar.AirBagDetails = txtAirbag.Text;
                objcar.BootSpace = Convert.ToInt32(txtBootSpace.Text);
                objcar.Price = Convert.ToDouble(txtPrice.Text);

                CarUpdated = CarBAL.UpdateCarBAL(objcar);


                if (CarUpdated)
                {
                    MessageBox.Show("Car details added successfully.");
                }
                else
                {
                    MessageBox.Show("car details couldn't be added.");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Searchcarbymodel()
        {
            try
            {
                string model = txtModel.Text;
                if (txtModel.Text != "")
                {
                    CarEntities objCar = CarBAL.SearchCarByModelBAL(model);
                    if (objCar != null)
                    {
                        cmbManufacturerName.Text = objCar.ManufacturerName.ToString();
                        cmbType.Text = objCar.Type.ToString();
                        txtEngine.Text = objCar.Engine;
                        txtBHP.Text = objCar.BHP.ToString();
                        cmbTransmissionId.Text = objCar.Transmission.ToString();
                        txtMileage.Text = objCar.Mileage.ToString();
                        txtSeats.Text = objCar.Seats.ToString();
                        txtAirbag.Text = objCar.AirBagDetails;
                        txtBootSpace.Text = objCar.BootSpace.ToString();
                        txtPrice.Text = objCar.Price.ToString();
                    }
                    else
                    {
                        MessageBox.Show("No Car records available.");
                    }
                }
                else
                    MessageBox.Show("Please Enter Model");

            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchCarByModel_Click(object sender, RoutedEventArgs e)
        {
            Searchcarbymodel();
        }

        private void BtnReturn_Click(object sender, RoutedEventArgs e)
        {
            Admin adm = new Admin();
            adm.Show();
            this.Close();

        }
    }
}
