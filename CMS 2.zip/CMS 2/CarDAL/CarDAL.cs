﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMSEntities;
using CMSExceptions;

namespace CMSDAL
{
    public class CarDAL
    {

        SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CMSConnectionString"].ConnectionString);
        SqlDataReader objDr;
        public bool AddCarDAL(CarEntities objCar)
        {
            bool CarAdded = false;
            try
            {

                SqlCommand objCom = new SqlCommand("[46008575].AddCarDetails", objCon);
                objCom.CommandType = CommandType.StoredProcedure;



                SqlParameter objSqlParam_ManufacturerName = new SqlParameter("@MName", objCar.ManufacturerName);
                SqlParameter objSqlParam_Model = new SqlParameter("@model", objCar.Model);
                SqlParameter objSqlParam_Type = new SqlParameter("@Type", objCar.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", objCar.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", objCar.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@Transmission", objCar.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", objCar.Mileage);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seat", objCar.Seats);
                SqlParameter objSqlParam_Airbag = new SqlParameter("@AirBagDetails", objCar.AirBagDetails);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", objCar.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@price", objCar.Price);


                objCom.Parameters.Add(objSqlParam_ManufacturerName);
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_Airbag);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);

                objCon.Open();
                objCom.ExecuteNonQuery();
                CarAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarAdded;

        }
        public bool UpdateCarDAL(CarEntities objCar)
        {
            bool carUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008575].UpdateCarDetails", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //


                SqlParameter objSqlParam_ManufacturerName = new SqlParameter("@MName", objCar.ManufacturerName);
                SqlParameter objSqlParam_Model = new SqlParameter("@model", objCar.Model);
                SqlParameter objSqlParam_Type = new SqlParameter("@Type", objCar.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", objCar.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", objCar.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@Transmission", objCar.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", objCar.Mileage);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seat", objCar.Seats);
                SqlParameter objSqlParam_Airbag = new SqlParameter("@AirBagDetails", objCar.AirBagDetails);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", objCar.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@price", objCar.Price);


                //
                objCon.Open();

                objCom.Parameters.Add(objSqlParam_ManufacturerName);
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_Airbag);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);
                objCom.ExecuteNonQuery();
                carUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return carUpdated;
        }
        public bool DeleteCarDAL(string model)
        {
            bool carDeleted = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["CMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008575].DeleteCarDetails", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@model", model);
                //
                objCom.Parameters.Add(objSqlParam_Id);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                carDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return carDeleted;
        }
        public CarEntities SearchCarByModelDAL(string model)
        {
            CarEntities objCar = null;
            try
            {
                objCon.Open();
                SqlCommand objCom = new SqlCommand("[46008575].SearchCarByModel", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCom.Parameters.AddWithValue("@model", model);
                //
                objDr = objCom.ExecuteReader();
                objDr.Read();
                if (objDr.HasRows)
                {
                    objCar = new CarEntities();
                    //Binding Object with DataReader
                    objCar.Model = objDr[0].ToString();
                    objCar.ManufacturerName = objDr[1].ToString();
                    objCar.Type = objDr[2].ToString();
                    objCar.Engine = objDr[3].ToString();
                    objCar.BHP = Convert.ToInt32(objDr[4].ToString());
                    objCar.Transmission = objDr[5].ToString();
                    objCar.Mileage = Convert.ToInt32(objDr[6].ToString());
                    objCar.AirBagDetails = objDr[7].ToString();
                    objCar.BootSpace = Convert.ToInt32(objDr[8].ToString());
                    objCar.Seats = Convert.ToInt32(objDr[9].ToString());
                    objCar.Price = Convert.ToDouble(objDr[10].ToString());
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objCar;
        }
        public List<CarEntities> SearchCarByNameDAL(string name,string type)
        {
            List<CarEntities> objCars = new List<CarEntities>();
            try
            {
                objCon.Open();
                SqlCommand objCom = new SqlCommand("[46008575].SearchCarByname", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                objCom.Parameters.AddWithValue("@ManufacturerName", name);
                objCom.Parameters.AddWithValue("@CarType", type);

                objDr = objCom.ExecuteReader();
                if (objDr.HasRows)
                {
                    while (objDr.Read())
                    {
                        CarEntities car = new CarEntities();
                        car.ManufacturerName = objDr[1].ToString();
                        car.Model = objDr[0].ToString();
                        car.Type = objDr[2].ToString();
                        car.Price = Convert.ToDouble(objDr[10].ToString());
                        objCars.Add(car);
                    }
                }
            }
            catch (Exception se)
            {
                throw se;
            }
            finally
            {
                objCon.Close();
            }
            return objCars;
        }
        public List<CarEntities> ListAllCars(string name, string type)
        {
            List<CarEntities> objCars = new List<CarEntities>();
            try
            {
                objCon.Open();
                SqlCommand objCom = new SqlCommand("[46008575].CarList", objCon);
                objCom.CommandType = CommandType.StoredProcedure;              
                objDr = objCom.ExecuteReader();
                if (objDr.HasRows)
                {
                    while (objDr.Read())
                    {
                        CarEntities car = new CarEntities();
                        car.ManufacturerName = objDr[0].ToString();
                        car.Model = objDr[1].ToString();
                        car.Type = objDr[2].ToString();
                        car.Price = Convert.ToDouble(objDr[3].ToString());
                        objCars.Add(car);
                    }
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objCars;
        }
        public bool UserDAL(string User,string Pwd)
        {
            bool validate = false;
            try
            {
                SqlCommand objCom = new SqlCommand("[46008575].ValidateLogin", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCom.Parameters.AddWithValue("@userid", User);
                objCom.Parameters.AddWithValue("@password", Pwd);
                objCon.Open();
                objDr = objCom.ExecuteReader();
                objDr.Read();
                if(objDr.HasRows)
                {
                    validate = true;
                }
                objCon.Close();
                return validate;
            
            }
            catch(SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
        }

    }
}